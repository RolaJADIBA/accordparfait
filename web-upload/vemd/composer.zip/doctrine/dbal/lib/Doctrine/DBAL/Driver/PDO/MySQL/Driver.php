<?php

namespace Doctrine\DBAL\Driver\PDO\MySQL;

use Doctrine\DBAL\Driver\PDOMySql;

final class Driver extends PDOMySql\Driver
{
}
