PSR Http Link
=============

This repository holds all interfaces/classes/traits related to
[PSR-13](https://github.com/php-fig/fig-standards/blob/master/proposed/links.md).

Note that this is not an HTTP link implementation of its own. It is merely an
interface that describes an HTTP link. See the specification for more details.
