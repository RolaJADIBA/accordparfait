<?php

namespace ContainerN4OGLsD;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderb83fa = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf0cfa = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties6a478 = [
        
    ];

    public function getConnection()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getConnection', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getMetadataFactory', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getExpressionBuilder', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'beginTransaction', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getCache', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'transactional', array('func' => $func), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->transactional($func);
    }

    public function commit()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'commit', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->commit();
    }

    public function rollback()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'rollback', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getClassMetadata', array('className' => $className), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'createQuery', array('dql' => $dql), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'createNamedQuery', array('name' => $name), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'createQueryBuilder', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'flush', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'clear', array('entityName' => $entityName), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->clear($entityName);
    }

    public function close()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'close', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->close();
    }

    public function persist($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'persist', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'remove', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'refresh', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'detach', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'merge', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'contains', array('entity' => $entity), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getEventManager', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getConfiguration', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'isOpen', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getUnitOfWork', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getProxyFactory', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'initializeObject', array('obj' => $obj), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'getFilters', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'isFiltersStateClean', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'hasFilters', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return $this->valueHolderb83fa->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf0cfa = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderb83fa) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderb83fa = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderb83fa->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__get', ['name' => $name], $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        if (isset(self::$publicProperties6a478[$name])) {
            return $this->valueHolderb83fa->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb83fa;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderb83fa;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb83fa;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderb83fa;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__isset', array('name' => $name), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb83fa;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderb83fa;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__unset', array('name' => $name), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb83fa;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderb83fa;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__clone', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        $this->valueHolderb83fa = clone $this->valueHolderb83fa;
    }

    public function __sleep()
    {
        $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, '__sleep', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;

        return array('valueHolderb83fa');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf0cfa = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf0cfa;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf0cfa && ($this->initializerf0cfa->__invoke($valueHolderb83fa, $this, 'initializeProxy', array(), $this->initializerf0cfa) || 1) && $this->valueHolderb83fa = $valueHolderb83fa;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderb83fa;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderb83fa;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
